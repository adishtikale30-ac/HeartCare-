# ❤️ HeartCare AI – Cardiovascular Disease Prediction

A Python + Machine Learning portfolio project that explores cardiovascular disease data, compares five classification algorithms, and provides an interactive Streamlit dashboard for educational demonstrations.

> **Medical disclaimer:** This project is for learning and demonstration only. It is not a medical device, diagnosis, screening recommendation, or substitute for professional medical care. Do not use its predictions to make health decisions.

## Features

- Data cleaning and preprocessing
- Exploratory data analysis and interactive Plotly charts
- Feature correlation heatmap
- Five ML models: Logistic Regression, KNN, Decision Tree, Random Forest, SVM
- Model comparison using accuracy, precision, recall, F1-score and ROC-AUC
- Best-model selection using F1-score
- Streamlit dashboard with a sample prediction form
- Confusion matrix and model comparison chart

## Dataset

The project uses `cardio_train.csv` (70,000 rows in the supplied source file). It contains:

| Column | Meaning |
|---|---|
| age | Age; source values are converted from days to years |
| gender | Encoded gender category (1 or 2) |
| height | Height in centimetres |
| weight | Weight in kilograms |
| ap_hi | Systolic blood pressure |
| ap_lo | Diastolic blood pressure |
| cholesterol | Cholesterol category (1–3) |
| gluc | Glucose category (1–3) |
| smoke | Smoking indicator (0/1) |
| alco | Alcohol indicator (0/1) |
| active | Physical activity indicator (0/1) |
| cardio | Target label (0/1) |

The `id` field is removed because it is an identifier, not a meaningful health feature.

## Project structure

```text
HeartCare_AI_Project/
├── app.py
├── train_model.py
├── cardio_train.csv
├── requirements.txt
├── README.md
├── .gitignore
└── outputs/
    └── .gitkeep
```

## Run locally

### 1. Install Python
Use Python 3.10 or newer.

### 2. Open a terminal in this folder

Create and activate a virtual environment (recommended):

**Windows**
```bash
python -m venv .venv
.venv\Scripts\activate
```

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install packages
```bash
pip install -r requirements.txt
```

### 4. Train and compare models
```bash
python train_model.py
```

This creates `best_model.pkl` and files in `outputs/`.

### 5. Launch the dashboard
```bash
streamlit run app.py
```

Your browser should open the local Streamlit application.

## Data preprocessing notes

The training script:
- detects the source delimiter,
- converts age from days to years when appropriate,
- removes the record ID,
- filters impossible/out-of-range values using documented broad bounds,
- removes duplicate records,
- imputes missing values inside the training pipeline,
- scales numerical features and one-hot encodes categorical features,
- uses a stratified 80/20 train/test split.

The broad range filters are project assumptions for data cleaning, not clinical reference ranges. Review them with your instructor before changing them.

## Reference results from the supplied dataset

One run on the provided 70,000-row CSV retained **67,943 records** after the documented cleaning filters. With a stratified 80/20 split and random state 42, the measured results were:

| Model | Accuracy | Precision | Recall | F1-score | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Logistic Regression | 0.7214 | 0.7444 | 0.6697 | 0.7051 | 0.7858 |
| K-Nearest Neighbors | 0.7023 | 0.7065 | 0.6866 | 0.6964 | 0.7541 |
| Decision Tree | 0.7234 | 0.7453 | 0.6742 | 0.7079 | 0.7899 |
| Random Forest | **0.7282** | 0.7459 | 0.6878 | **0.7157** | **0.7963** |
| Support Vector Machine | 0.7209 | **0.7480** | 0.6617 | 0.7022 | 0.7857 |

Random Forest was selected by F1-score in this run. These are reproducible project results for this particular split, not evidence of clinical performance. Results can vary with package versions or changes to the data and code.

## Evaluation

The project reports:
- Accuracy
- Precision
- Recall
- F1-score
- ROC-AUC

The best model is selected by F1-score to avoid relying on accuracy alone. Actual results are generated on your machine from the supplied dataset; do not copy guessed performance numbers into your report.

## GitHub upload

1. Create a new public repository named `HeartCare-AI`.
2. Add a short description: `Cardiovascular disease prediction using Python, scikit-learn and Streamlit.`
3. Upload the project files (or use the Git commands below).
4. Commit with message: `Add HeartCare AI ML project`.
5. Add screenshots of the dashboard to the repository README after running the app.

```bash
git init
git add .
git commit -m "Add HeartCare AI ML project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/HeartCare-AI.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## Suggested LinkedIn post

🚀 Excited to share my Python + Machine Learning project: **HeartCare AI – Cardiovascular Disease Prediction!**

In this project, I worked with a cardiovascular dataset and built a machine learning workflow that includes data preprocessing, exploratory data analysis, correlation analysis, and comparison of five classification algorithms:
- Logistic Regression
- K-Nearest Neighbors
- Decision Tree
- Random Forest
- Support Vector Machine

I also created an interactive Streamlit dashboard to explore the dataset and demonstrate model predictions.

**Tech stack:** Python, Pandas, Scikit-learn, Matplotlib, Seaborn, Plotly, Streamlit.

This project helped me strengthen my understanding of data analysis, model evaluation, and building practical ML applications.

GitHub: [Add your repository link]

#Python #MachineLearning #DataScience #Streamlit #ArtificialIntelligence #StudentProject

## Future improvements

- Add cross-validation and hyperparameter tuning.
- Add calibration and threshold analysis.
- Add model explainability with SHAP.
- Add unit tests and a reproducible experiment log.
- Deploy the dashboard using Streamlit Community Cloud.
