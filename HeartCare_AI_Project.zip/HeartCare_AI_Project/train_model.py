from pathlib import Path
import json
import warnings

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score,
    ConfusionMatrixDisplay, RocCurveDisplay
)
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "cardio_train.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

def load_and_clean_data(path=DATA_PATH):
    """Load the semicolon/comma separated dataset and apply transparent cleaning."""
    try:
        data = pd.read_csv(path, sep=None, engine="python")
    except Exception:
        data = pd.read_csv(path, sep=";")

    data.columns = [c.strip().lower() for c in data.columns]
    required = {
        "age", "gender", "height", "weight", "ap_hi", "ap_lo",
        "cholesterol", "gluc", "smoke", "alco", "active", "cardio"
    }
    missing = required - set(data.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")

    # Convert age from days to years when values look like day counts.
    if data["age"].median() > 150:
        data["age"] = (data["age"] / 365.25).round(1)

    # Remove the record identifier; it is not a health predictor.
    data = data.drop(columns=["id"], errors="ignore")

    # Keep plausible ranges and remove impossible blood-pressure records.
    data = data[
        data["height"].between(120, 220)
        & data["weight"].between(30, 250)
        & data["ap_hi"].between(70, 250)
        & data["ap_lo"].between(40, 200)
        & (data["ap_hi"] >= data["ap_lo"])
        & data["age"].between(18, 100)
    ].copy()

    data = data.drop_duplicates()
    data = data.dropna(subset=["cardio"])
    data["cardio"] = data["cardio"].astype(int)
    return data

def build_preprocessor():
    numeric_features = ["age", "height", "weight", "ap_hi", "ap_lo"]
    categorical_features = [
        "gender", "cholesterol", "gluc", "smoke", "alco", "active"
    ]
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    return ColumnTransformer([
        ("numeric", numeric_pipe, numeric_features),
        ("categorical", categorical_pipe, categorical_features)
    ])

def main():
    print("Loading and cleaning dataset...")
    data = load_and_clean_data()
    X = data.drop(columns=["cardio"])
    y = data["cardio"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1500, class_weight="balanced"),
        "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=7),
        "Decision Tree": DecisionTreeClassifier(
            max_depth=8, min_samples_leaf=20, class_weight="balanced", random_state=42
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=180, max_depth=14, min_samples_leaf=5,
            class_weight="balanced", n_jobs=-1, random_state=42
        ),
        "Support Vector Machine": LinearSVC(
            class_weight="balanced", random_state=42, max_iter=5000
        )
    }

    results = {}
    fitted = {}
    preprocessor = build_preprocessor()

    for name, estimator in models.items():
        print(f"Training {name}...")
        pipe = Pipeline([
            ("preprocessing", build_preprocessor()),
            ("model", estimator)
        ])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        probability = (pipe.predict_proba(X_test)[:, 1] if hasattr(pipe, "predict_proba")
                       else pipe.decision_function(X_test))

        results[name] = {
            "accuracy": float(accuracy_score(y_test, pred)),
            "precision": float(precision_score(y_test, pred, zero_division=0)),
            "recall": float(recall_score(y_test, pred, zero_division=0)),
            "f1_score": float(f1_score(y_test, pred, zero_division=0)),
            "roc_auc": float(roc_auc_score(y_test, probability))
        }
        fitted[name] = pipe
        print(f"  Accuracy: {results[name]['accuracy']:.4f} | "
              f"F1: {results[name]['f1_score']:.4f} | "
              f"ROC-AUC: {results[name]['roc_auc']:.4f}")

    # Select the model by F1 score, not accuracy alone.
    best_name = max(results, key=lambda n: results[n]["f1_score"])
    best_model = fitted[best_name]
    best_pred = best_model.predict(X_test)

    joblib.dump(best_model, ROOT / "best_model.pkl")
    with open(OUTPUT_DIR / "metrics.json", "w") as f:
        json.dump({
            "best_model": best_name,
            "rows_after_cleaning": int(len(data)),
            "rows_before_cleaning": int(pd.read_csv(DATA_PATH, sep=None, engine="python").shape[0]),
            "results": results,
            "classification_report": classification_report(
                y_test, best_pred, output_dict=True, zero_division=0
            )
        }, f, indent=2)

    # Confusion matrix for the selected model.
    fig, ax = plt.subplots(figsize=(5, 4))
    ConfusionMatrixDisplay.from_predictions(
        y_test, best_pred, cmap="Blues", ax=ax, colorbar=False
    )
    ax.set_title(f"Confusion Matrix – {best_name}")
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "confusion_matrix.png", dpi=160)
    plt.close(fig)

    # Model comparison chart.
    score_df = pd.DataFrame(results).T.sort_values("f1_score", ascending=False)
    ax = score_df[["accuracy", "precision", "recall", "f1_score"]].plot(
        kind="bar", figsize=(11, 5), ylim=(0, 1), rot=20
    )
    ax.set_title("Machine Learning Model Comparison")
    ax.set_ylabel("Score")
    ax.set_xlabel("")
    ax.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "model_comparison.png", dpi=160)
    plt.close()

    print("\nTraining completed.")
    print(f"Best model by F1 score: {best_name}")
    print("Saved best_model.pkl and outputs/metrics.json")
    print("Note: this is a teaching/demo model, not a medical diagnostic system.")

if __name__ == "__main__":
    main()
