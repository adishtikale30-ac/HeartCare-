from pathlib import Path
import json
import subprocess
import sys

import joblib
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from train_model import load_and_clean_data

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "cardio_train.csv"
MODEL_PATH = ROOT / "best_model.pkl"
METRICS_PATH = ROOT / "outputs" / "metrics.json"

st.set_page_config(
    page_title="HeartCare AI | Health Analytics",
    page_icon="❤️",
    layout="wide"
)

# Clean, modern dashboard styling.
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap');
html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
.stApp { background: #f4f7fb; }
.block-container { padding-top: 1.7rem; }
.hero {
  background: linear-gradient(115deg, #102b46, #176b78);
  padding: 28px 32px; border-radius: 18px; color: white; margin-bottom: 22px;
}
.hero h1 { color: white; margin: 0; font-size: 2.2rem; }
.hero p { color: #d6edf0; margin: 7px 0 0 0; }
.metric-card {
  background: white; padding: 18px 20px; border-radius: 14px;
  border: 1px solid #e5ebf2; box-shadow: 0 3px 12px rgba(20,40,60,.04);
}
.metric-label { color: #66788a; font-size: .88rem; }
.metric-value { color: #102b46; font-size: 1.65rem; font-weight: 700; }
.note { background:#fff7e8; border-left:4px solid #e3a43b; padding:12px 15px;
        border-radius:8px; color:#684b1b; }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def get_data():
    return load_and_clean_data(DATA_PATH)

@st.cache_resource
def get_model():
    if not MODEL_PATH.exists():
        with st.spinner("First-time setup: training the five ML models..."):
            subprocess.run(
                [sys.executable, str(ROOT / "train_model.py")],
                cwd=ROOT, check=True
            )
    return joblib.load(MODEL_PATH)

@st.cache_data
def get_metrics():
    if METRICS_PATH.exists():
        return json.loads(METRICS_PATH.read_text())
    return None

data = get_data()
model = get_model()
metrics = get_metrics()

st.markdown("""
<div class="hero">
  <h1>❤️ HeartCare AI</h1>
  <p>Cardiovascular risk prediction · Machine learning · Health data insights</p>
</div>
""", unsafe_allow_html=True)

tab1, tab2, tab3 = st.tabs(["📊 Overview", "🧪 Risk Prediction", "📈 Model Performance"])

with tab1:
    st.subheader("Dataset overview")
    total = len(data)
    positive = int(data["cardio"].sum())
    negative = total - positive
    c1, c2, c3, c4 = st.columns(4)
    for col, label, value in [
        (c1, "Clean records", f"{total:,}"),
        (c2, "Target = 1", f"{positive:,}"),
        (c3, "Target = 0", f"{negative:,}"),
        (c4, "Features", str(data.shape[1] - 1))
    ]:
        with col:
            st.markdown(
                f'<div class="metric-card"><div class="metric-label">{label}</div>'
                f'<div class="metric-value">{value}</div></div>',
                unsafe_allow_html=True
            )
    st.write("")
    left, right = st.columns(2)
    with left:
        counts = data["cardio"].value_counts().rename_axis("Cardio label").reset_index(name="Patients")
        counts["Cardio label"] = counts["Cardio label"].map({0: "No recorded disease", 1: "Disease present"})
        fig = px.pie(counts, names="Cardio label", values="Patients",
                     hole=.55, title="Target class distribution")
        st.plotly_chart(fig, use_container_width=True)
    with right:
        age_plot = data.assign(age_group=(data["age"] // 10 * 10).astype(int))
        age_plot = age_plot.groupby(["age_group", "cardio"]).size().reset_index(name="Patients")
        age_plot["Cardio status"] = age_plot["cardio"].map({0: "0 – No", 1: "1 – Yes"})
        fig = px.bar(age_plot, x="age_group", y="Patients", color="Cardio status",
                     barmode="group", title="Patient distribution by age group")
        st.plotly_chart(fig, use_container_width=True)

    left, right = st.columns(2)
    with left:
        fig = px.histogram(data, x="ap_hi", color="cardio", nbins=35,
                           barmode="overlay", opacity=.7,
                           title="Systolic blood pressure distribution",
                           labels={"ap_hi": "Systolic BP", "cardio": "Cardio label"})
        st.plotly_chart(fig, use_container_width=True)
    with right:
        fig = px.box(data, x="cardio", y="weight", color="cardio",
                     title="Weight distribution by target",
                     labels={"cardio": "Cardio label", "weight": "Weight (kg)"})
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Correlation matrix")
    corr = data.corr(numeric_only=True)
    fig = px.imshow(corr, text_auto=".2f", aspect="auto",
                    color_continuous_scale="RdBu_r", zmin=-1, zmax=1,
                    title="Feature correlation heatmap")
    st.plotly_chart(fig, use_container_width=True)
    st.caption("Correlation indicates association, not causation.")

with tab2:
    st.subheader("Patient information")
    st.markdown(
        '<div class="note">Educational demonstration only. This output is not a diagnosis, '
        'medical advice, or a substitute for a qualified clinician.</div>',
        unsafe_allow_html=True
    )
    st.write("")
    with st.form("prediction_form"):
        a, b, c = st.columns(3)
        with a:
            age = st.slider("Age (years)", 18, 100, 45)
            gender = st.selectbox("Gender code", [1, 2],
                                  format_func=lambda x: "Female (1)" if x == 1 else "Male (2)")
            height = st.number_input("Height (cm)", 120, 220, 165)
            weight = st.number_input("Weight (kg)", 30.0, 250.0, 70.0, step=0.5)
        with b:
            ap_hi = st.number_input("Systolic BP (ap_hi)", 70, 250, 120)
            ap_lo = st.number_input("Diastolic BP (ap_lo)", 40, 200, 80)
            cholesterol = st.selectbox("Cholesterol", [1, 2, 3],
                                       format_func=lambda x: {1:"Normal",2:"Above normal",3:"Well above normal"}[x])
            gluc = st.selectbox("Glucose", [1, 2, 3],
                                format_func=lambda x: {1:"Normal",2:"Above normal",3:"Well above normal"}[x])
        with c:
            smoke = st.selectbox("Smokes", [0, 1], format_func=lambda x: "No" if x == 0 else "Yes")
            alco = st.selectbox("Alcohol intake", [0, 1], format_func=lambda x: "No" if x == 0 else "Yes")
            active = st.selectbox("Physically active", [0, 1], format_func=lambda x: "No" if x == 0 else "Yes")
        submitted = st.form_submit_button("🔍 Predict", use_container_width=True)

    if submitted:
        if ap_hi < ap_lo:
            st.error("Please check the blood pressure values: systolic BP should normally be higher than diastolic BP.")
        else:
            patient = pd.DataFrame([{
                "age": float(age), "gender": int(gender), "height": float(height),
                "weight": float(weight), "ap_hi": int(ap_hi), "ap_lo": int(ap_lo),
                "cholesterol": int(cholesterol), "gluc": int(gluc),
                "smoke": int(smoke), "alco": int(alco), "active": int(active)
            }])
            if hasattr(model, "predict_proba"):
                probability = float(model.predict_proba(patient)[0, 1])
                score_label = "Estimated model probability for class 1"
                prediction = int(probability >= 0.5)
            else:
                raw_score = float(model.decision_function(patient)[0])
                probability = 1.0 / (1.0 + __import__("math").exp(-max(min(raw_score, 30), -30)))
                score_label = "Scaled SVM score (not a calibrated probability)"
                prediction = int(raw_score >= 0)
            st.divider()
            st.subheader("Model output")
            m1, m2 = st.columns(2)
            with m1:
                if prediction == 1:
                    st.warning("The model estimates a higher likelihood of the positive class.")
                else:
                    st.success("The model estimates a lower likelihood of the positive class.")
            with m2:
                st.metric(score_label, f"{probability:.1%}")
            st.progress(probability)
            st.caption("The threshold is a demonstration setting, not a clinically validated cutoff. SVM scores are scaled for display and are not calibrated probabilities.")

with tab3:
    st.subheader("Model comparison")
    if metrics:
        st.caption(f"Best model selected by F1 score: **{metrics['best_model']}**")
        score_df = pd.DataFrame(metrics["results"]).T.reset_index(names="Model")
        score_df = score_df.rename(columns={
            "accuracy":"Accuracy", "precision":"Precision",
            "recall":"Recall", "f1_score":"F1 score", "roc_auc":"ROC-AUC"
        })
        st.dataframe(score_df.style.format({
            "Accuracy":"{:.3f}", "Precision":"{:.3f}", "Recall":"{:.3f}",
            "F1 score":"{:.3f}", "ROC-AUC":"{:.3f}"
        }), use_container_width=True, hide_index=True)
        fig = px.bar(score_df.melt(id_vars="Model", var_name="Metric", value_name="Score"),
                     x="Model", y="Score", color="Metric", barmode="group",
                     title="Performance of five machine learning models",
                     range_y=[0, 1])
        st.plotly_chart(fig, use_container_width=True)
        cm_path = ROOT / "outputs" / "confusion_matrix.png"
        if cm_path.exists():
            st.image(str(cm_path), caption="Confusion matrix for selected model", width=520)
        st.caption(f"Cleaned dataset rows: {metrics['rows_after_cleaning']:,}")
    else:
        st.info("Model metrics will appear after training.")

st.divider()
st.caption("HeartCare AI · Student portfolio project · For educational use only")
